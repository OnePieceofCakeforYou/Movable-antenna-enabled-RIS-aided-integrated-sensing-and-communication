function [BS_CU,IRS_CU]=generate_CU_location(num_CU)

x=20+20*rand(1,num_CU);
y=-20*rand(1,num_CU);



% BS坐标位于(0,0)
BS_CU=sqrt(x.^2+y.^2);

% IRS坐标位于(12,16)
IRS_CU=sqrt((x-12).^2+(y-16).^2);
end