%将M分解成接近的一对整数
function [X_num, Y_num] = decompose_even_number(M)
    X_num = ceil(sqrt(M));
    Y_num = M / X_num;
    while mod(Y_num,1)~= 0
        X_num = X_num + 1;
        Y_num = M / X_num;
    end
end