% 计算发射/接收FRM矩阵
function [FRM] = cal_FRV_Matrix(v,theta,phi,lambda)
    % v 中存放的是天线位置坐标
    x_angle = sin(theta).*cos(phi);
    y_angle = cos(theta);
    angle_gather = [x_angle,y_angle];
    diff_dis = angle_gather * v;
    phase = diff_dis/lambda * (2*pi);
    FRM = exp(1j * phase);%FRM矩阵是L*M，L表示传输路径的数量
end